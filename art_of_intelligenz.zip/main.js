
function openSocial(url) {
    const text = document.getElementById('postText').value;
    const finalUrl = url + '?text=' + encodeURIComponent(text);
    window.open(finalUrl, '_blank');
}
